import pymysql
import string
import secrets
def get_login(acc):
    return acc.partition(':')[0]
def get_pass(acc):
    return acc[acc.find(":") + 1:].replace("\n","")

def generate_alphanum_crypt_string( length):
    letters_and_digits = string.ascii_letters + string.digits
    crypt_rand_string = ''.join(secrets.choice(
        letters_and_digits) for i in range(length))
    return crypt_rand_string

def get_card_for_post(phone, passw):
    con = pymysql.connect(host="localhost", user="root", password="123456", database='qr_code', port=3306)
    key = generate_alphanum_crypt_string(8)
    with con:
        cur = con.cursor()
        cur.execute(f'INSERT INTO qr (key_qr, phone, passw) VALUES (%s, %s, %s)', (key, phone, passw))
        con.commit()
        print(key)

def get_all_acc():
    file1 = open("base.txt", "r")
    st = []
    while True:
        # считываем строку
        line = file1.readline()
        st.append(line)
        # прерываем цикл, если строка пустая
        if not line:
            break
    file1.close
    return st



accaunts = get_all_acc()

for acc in accaunts:
    phone = get_login(acc)
    passw = get_pass(acc)
    get_card_for_post(phone, passw)